import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JSplitPane;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import java.awt.event.ActionListener;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Shape;
import java.awt.CardLayout;
import javax.swing.SpringLayout;
import javax.swing.JTable;
import java.awt.Graphics;
import java.awt.Graphics2D;
public class main extends JPanel {

	private JFrame frame;
	private JTable tablerectange;
	private JTable tablecicle;

	/**
	 * Launch the application.
	 */
	public void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    Graphics2D g2d = (Graphics2D) g;

	    g2d.setColor(new Color(212, 212, 212));
	    g2d.drawRect(10, 15, 90, 60);


	    g2d.setColor(new Color(31, 21, 1));
	    g2d.fillRect(250, 195, 90, 60);

	  }
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				Rectangle rec= new Rectangle();
				My2Dpaint my=new My2Dpaint(new MyGraphics(80,50,500,500));
				try {
					
					main window = new main();
					//window.frame.getContentPane().add(rec);
					window.frame.setContentPane(my);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			
			}
		});
	}

	/**
	 * Create the application.
	 */
	public main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setEnabled(false);
		frame.setBounds(100, 100, 711, 468);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(742, 10, -184, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Redo");
		btnNewButton_2.setBounds(429, 10, 74, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Undo");
		btnNewButton_3.setBounds(349, 10, 74, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Print");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			}
		});
		btnNewButton_4.setBounds(509, 10, 55, 23);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Remove");
		btnNewButton_5.setBounds(249, 10, 94, 23);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_1 = new JButton("3D");
		btnNewButton_1.setBounds(650, 10, 45, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_6 = new JButton("2D");
		btnNewButton_6.setBounds(599, 10, 45, 23);
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Add");
		btnNewButton_7.setBounds(169, 10, 74, 23);
		frame.getContentPane().add(btnNewButton_7);
		
		tablerectange = new JTable();
		tablerectange.setBounds(10, 57, 183, 118);
		frame.getContentPane().add(tablerectange);
		
		tablecicle = new JTable();
		tablecicle.setBounds(10, 242, 183, 118);
		frame.getContentPane().add(tablecicle);
		
		JPanel panel = new JPanel();
		panel.setBounds(312, 80, 332, 299);
		frame.getContentPane().add(panel);
	}
}

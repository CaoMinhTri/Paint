
public class My3Dpaint {

}

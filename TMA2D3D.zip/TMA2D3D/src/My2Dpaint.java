import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

import javax.swing.JPanel;

public class My2Dpaint  extends JPanel{
	MyGraphics my;
	
public My2Dpaint(MyGraphics my) {
		super();
		this.my = my;
	}

@SuppressWarnings("null")
public void drawCir(Graphics g){
	Graphics2D g2d = (Graphics2D) g;
	g2d.drawOval(50,50,50,50);
//	Ellipse2D.Double circle = new Ellipse2D.Double(50,50,50,50);
	//g2d.draw(circle);
	//g2d.setColor(new Color(200,255,255));
	 //  g2d.fill(circle);
	
}
public void drawRect(Graphics g){
	//Graphics g = null;
	Graphics2D g2d = (Graphics2D) g;
	 g2d.drawRect(my.x,my.y,my.h,my.w);
}
@Override
public void paintComponent(Graphics g) {

    super.paintComponent(g);
    drawRect(g);
    drawCir(g);
}
}

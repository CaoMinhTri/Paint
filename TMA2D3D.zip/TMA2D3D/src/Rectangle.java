import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JPanel;
public class Rectangle extends JPanel{
	public void doDrawing(Graphics g) {
	    super.paintComponent(g);
	    g.create(25, 10, 50, 75);
	    Graphics2D g2d = (Graphics2D) g;
	    g.setColor (Color.gray);
	    g.draw3DRect (25, 10, 50, 75, true);
	    g.draw3DRect (25, 110, 50, 75, true);
	    g.fill3DRect (100, 10, 50, 75, true);
	    g.fill3DRect (100, 110, 50, 75, false);
	    g2d.setColor(new Color(212, 212, 212));
	   


	 //   g2d.setColor(new Color(31, 21, 1));
	    g2d.fillRect(250, 195, 90, 60);

	  }
	 @Override
	    public void paintComponent(Graphics g) {

	        super.paintComponent(g);
	        doDrawing(g);
	    }
}

package model;

import java.util.List;

import javax.swing.undo.AbstractUndoableEdit;

public class UndoablePaint extends AbstractUndoableEdit {

	protected List<Circle> listCirle;
	protected List<Rectangle> listRectangle;
	protected Rectangle rectangle;
	protected Circle circle;

	

	public UndoablePaint(List<Circle> listCirle, List<Rectangle> listRectangle, Rectangle rectangle, Circle circle) {
		super();
		this.listCirle = listCirle;
		this.listRectangle = listRectangle;
		this.rectangle = rectangle;
		this.circle = circle;
	}

	@Override
	public void undo() {

		if (!listCirle.isEmpty()) {
			super.undo();
			listCirle.remove(circle);
		}
		
		if(!listRectangle.isEmpty()){
			super.undo();
			listRectangle.remove(rectangle);
		}
	}

	@Override
	public void redo() {
		super.redo();
		listCirle.add(circle);
		listRectangle.add(rectangle);
	}

}